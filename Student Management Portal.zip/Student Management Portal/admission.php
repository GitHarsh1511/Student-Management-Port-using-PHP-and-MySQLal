<?php

session_start();

if (!isset($_SESSION['username'])) {
    header("location:login.php");
} elseif ($_SESSION['usertype'] == 'student') {
    header("location:login.php");
}

$host = "localhost";
$user = "root";
$password = "";
$db = "mnpwd";

$data = mysqli_connect($host, $user, $password, $db);

$sql = "SELECT * from admission";

$result = mysqli_query($data, $sql);

?>







<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>

    <?php

    include 'admin_css.php';

    ?>

</head>

<body>
    <?php include 'admin_sidebar.php'; ?>
    <div class="content">
        <center>
            <h1 class="heading">Applied For Admission</h1>
            <br><br>
            <table class="admission-table">
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Message</th>
                </tr>

                <?php
                while ($info = $result->fetch_assoc()) {
                ?>
                    <tr>
                        <td><?php echo "{$info['name']}" ?></td>
                        <td><?php echo "{$info['email']}" ?></td>
                        <td><?php echo "{$info['phone']}" ?></td>
                        <td><?php echo "{$info['message']}" ?></td>
                    </tr>
                <?php
                }
                ?>
            </table>
        </center>
    </div>

    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .content {
            padding: 20px;
            margin-top: 30px;
        }

        .heading {
            font-size: 36px;
            color: #333;
            margin-bottom: 20px;
        }

        table {
            width: 80%;
            margin-top: 20px;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 15px;
            text-align: left;
            font-size: 18px;
        }

        th {
            background-color: #3498db;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #e1e1e1;
        }

        td {
            color: #555;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            table {
                width: 100%;
            }
            
            .heading {
                font-size: 28px;
            }

            th, td {
                font-size: 16px;
                padding: 10px;
            }
        }
    </style>
</body>


</html>