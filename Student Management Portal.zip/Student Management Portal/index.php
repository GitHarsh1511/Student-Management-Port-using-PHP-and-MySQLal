<?php

error_reporting(0);
session_start();

$message = isset($_SESSION['message']) ? $_SESSION['message'] : '';
session_destroy();

if ($message) {
    echo "<script type='text/javascript'> alert('$message')</script>";
}

$host = "localhost";
$user = "root";
$password = "";
$db = "mnpwd";

$data = mysqli_connect($host, $user, $password, $db);

if (!$data) {
    die("Database connection failed.");
}

$sql = "SELECT * FROM teacher";
$result = mysqli_query($data, $sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Management System</title>
    <link rel="stylesheet" type="text/css" href="indexx.css">


</head>

<body>
    <header>
        <h2 class="logo">HM School</h2>
        <nav class="navigation">
            <a href="index.php">Home</a>
            <a href="#scabout">About</a>
            <a href="#admission-form">Admission</a>
            <a href="#footer">Contact</a>
            <a href="login.php"><button class="login-btn">Login</button></a>
        </nav>
    </header>


    <div class="section1">
        <!-- <label class="img_text">We Teach Students With Care</label>
        <img class="main_img" src="hms.jpg"> -->
    </div>

    <div class="container" id="scabout">
        <div class="row">
            <div class="col-md-4">
                <img class="welcome_img" src="ww.jpg">
            </div>
            <div class="col-md-8">
                <h1>Welcome to HM-School</h1>
                <p>Welcome to HM School, where education meets innovation! Nestled in the heart of a vibrant community, our school is dedicated to fostering a nurturing environment that inspires students to reach their full potential. At HM School, we believe that every child is unique, and we celebrate individuality through personalized learning experiences.</p>
            </div>
        </div>
    </div>

    <center>
        <h1>Our Teachers</h1>
    </center>
    <div class="ccontainer">
        <div class="row">
            <?php
            if ($result) {
                while ($info = $result->fetch_assoc()) {
            ?>
                    <div class="col-md-4">
                        <img class="teacher" src="<?php echo htmlspecialchars($info['image']); ?>">
                        <h3><?php echo htmlspecialchars($info['name']); ?></h3>
                        <h5><?php echo htmlspecialchars($info['description']); ?></h5>
                    </div>
            <?php
                }
            } else {
                echo "<p>No teachers available at the moment.</p>";
            }
            ?>
        </div>
    </div>

    <center>
        <h1>Our Courses</h1>
    </center>

    <div class="coontainer">
        <div class="row">
            <div class="col-md-4">
                <img class="course-img" src="sub1.jpg" alt="Science">
                <h2 class="course-title">Science</h2>
            </div>
            <div class="col-md-4">
                <img class="course-img" src="sub2.jpg" alt="Maths">
                <h2 class="course-title">Maths</h2>
            </div>
            <div class="col-md-4">
                <img class="course-img" src="sub3.jpg" alt="Biology">
                <h2 class="course-title">Biology</h2>
            </div>
        </div>
    </div>
    <br><br><br>
    <center>

        <div class="admission_form" id="admission-form">
            <h1>Admission Form</h1>
            <form action="data_check.php" method="POST">
                <div class="form-group">
                    <label class="label_text">Name</label>
                    <input class="input_deg" type="text" name="name" required>
                </div>

                <div class="form-group">
                    <label class="label_text">Email</label>
                    <input class="input_deg" type="email" name="email" required>
                </div>

                <div class="form-group">
                    <label class="label_text">Phone</label>
                    <input class="input_deg" type="tel" name="phone" required>
                </div>

                <div class="form-group">
                    <label class="label_text">Message</label>
                    <textarea class="input_txt" name="message" rows="4" required></textarea>
                </div>

                <div class="form-group">
                    <button class="submit_btn" type="submit" name="apply">Apply</button>
                </div>
            </form>
        </div>
    </center>
    <br><br><br>
    <footer class="footer" id="footer">
        <div class="footer-container">
            <div class="footer-section">
                <h2>HM School</h2>
                <p>Empowering students to achieve excellence and lifelong learning through quality education.</p>
            </div>
            <div class="footer-section">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="#scabout">About</a></li>
                    <li><a href="#admission-form">Admission</a></li>
                    <li><a href="#footer">Contact</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h3>Contact Us</h3>
                <p>Email: info@hmschool.com</p>
                <p>Phone: +123 456 7890</p>
                <p>Address: 123 School St., Anand, India</p>
            </div>
            <div class="footer-section">
                <h3>Follow Us</h3>
                <div class="social-icons">
                    <a href=""><img src="fb.png" alt="Facebook"></a>
                    <a href=""><img src="x.png" alt="Twitter"></a>
                    <a href=""><img src="ig.png" alt="Instagram"></a>
                    <a href=""><img src="ld.png" alt="LinkedIn"></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2024 HM School. All rights reserved.</p>
        </div>
    </footer>

</body>


</html>