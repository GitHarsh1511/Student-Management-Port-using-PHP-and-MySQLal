<?php

session_start();
error_reporting(0);

if (!isset($_SESSION['username'])) {
    header("location:login.php");
} elseif ($_SESSION['usertype'] == 'student') {
    header("location:login.php");
}

$host = "localhost";
$user = "root";
$password = "";
$db = "mnpwd";

$data = mysqli_connect($host, $user, $password, $db);

$sql = "SELECT * FROM teacher";

$result = mysqli_query($data, $sql);

if ($_GET['teacher_id']) {
    $t_id = $_GET['teacher_id'];

    $sql2 = "DELETE FROM teacher WHERE id='$t_id' ";

    $result2 = mysqli_query($data, $sql2);

    if ($result2) {
        header('location:admin_view_teacher.php');
    }
}
?>







<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <?php

    include 'admin_css.php';

    ?>

    <style type="text/css">
        /* General table styles */
        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            font-family: Arial, sans-serif;
        }

        /* Table header styling */
        .table_th {
            padding: 15px;
            font-size: 18px;
            text-align: center;
            background-color: #4CAF50;
            color: white;
            font-weight: bold;
            border: 1px solid #ddd;
        }

        /* Table data cell styling */
        .table_td {
            padding: 15px;
            font-size: 24px;
            text-align: center;
            border: 1px solid #ddd;
            background-color: #f2f2f2;
        }

        /* Image styling */
        .table_td img {
            border-radius: 50%;
            border: 2px solid #ddd;
        }

        /* Hover effect for table rows */
        tr:hover {
            background-color: #f1f1f1;
        }

        /* Button styles */
        .btn {
            padding: 8px 16px;
            margin: 5px;
            text-decoration: none;
            color: white;
            border-radius: 5px;
            font-size: 16px;
            text-align: center;
        }

        /* Danger button (Delete) */
        .btn-danger {
            background-color: #e74c3c;
        }

        .btn-danger:hover {
            background-color: #c0392b;
        }

        /* Primary button (Update) */
        .btn-primary {
            background-color: #3498db;
        }

        .btn-primary:hover {
            background-color: #2980b9;
        }

        /* Centered content */
        .content {
            padding: 20px;
        }

        h1 {
            font-size: 36px;
            /* Increased font size */
            margin: 0;
            /* Remove top margin */
            padding-top: 0;
            /* Remove top padding */
        }

        /* Responsive Design */
        @media screen and (max-width: 768px) {
            table {
                width: 95%;
            }

            .table_th,
            .table_td {
                font-size: 14px;
            }

            .btn {
                font-size: 14px;
            }
        }
    </style>


</head>

<body>
    <?php

    include 'admin_sidebar.php';

    ?>

    <div class="content">
        <center>
            <h1>View All Teacher Data</h1>
            <table border="1px">
                <tr>
                    <th class="table_th">Teacher Name</th>
                    <th class="table_th">About Name</th>
                    <th class="table_th">Image</th>
                    <th class="table_th">Delete</th>
                    <th class="table_th">Update</th>

                </tr>
                <?php
                while ($info = $result->fetch_assoc()) {
                ?>
                    <tr>
                        <td class="table_td">
                            <?php echo "{$info['name']}" ?>
                        </td>
                        <td class="table_td">
                            <?php echo "{$info['description']}" ?>
                        </td>

                        <td class="table_td">
                            <img height="100px" width="100px" src=" <?php echo "{$info['image']}" ?>">

                        </td>

                        <td class="table_td">
                            <?php
                            echo "
                            <a onClick=\"javascript:return confirm('Are You Sure To Detele This ? ');\"
                            class='btn btn-danger'
                            href='admin_view_teacher.php?teacher_id={$info['id']}'>
                            Delete
                            </a>";
                            ?>
                        </td>

                        <td class="table_td">

                            <?php
                            echo "
                            <a href='admin_update_teacher.php?teacher_id={$info['id']}' class='btn btn-primary'>Update</a>";

                            ?>

                        </td>
                    </tr>

                <?php
                }
                ?>
            </table>
        </center>
    </div>
</body>

</html>