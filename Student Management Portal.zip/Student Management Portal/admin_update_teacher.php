<?php

session_start();
error_reporting(0);

if (!isset($_SESSION['username'])) {
    header("location:login.php");
} elseif ($_SESSION['usertype'] == 'student') {
    header("location:login.php");
}

$host = "localhost";
$user = "root";
$password = "";
$db = "mnpwd";

$data = mysqli_connect($host, $user, $password, $db);

if ($_GET['teacher_id']) {
    $t_id = $_GET['teacher_id'];

    $sql = "SELECT * FROM teacher WHERE id='$t_id' ";

    $result = mysqli_query($data, $sql);

    $info = $result->fetch_assoc();
}

if (isset($_POST['update_teacher'])) {
    $id = $_POST['id'];

    $t_name = $_POST['name'];

    $t_des = $_POST['description'];

    $file = $_FILES['image']['name'];

    $dst = "./image/" . $file;

    $dst_db = "image/" . $file;

    move_uploaded_file($_FILES['image']['tmp_name'], $dst);

    if ($file) {
        $sql2 = "UPDATE teacher SET name='$t_name',description='$t_des',image='$dst_db' WHERE id='$id' ";
    } else {
        $sql2 = "UPDATE teacher SET name='$t_name',description='$t_des' WHERE id='$id' ";
    }


    $result2 = mysqli_query($data, $sql2);

    if ($result2) {
        header('location:admin_view_teacher.php');
    }
}
?>







<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <?php

    include 'admin_css.php';

    ?>

    <style>
        /* Content Container */
        .content {
            display: flex;
            flex-direction: column;
            /* Arrange title and form vertically */
            align-items: flex-start;
            /* Align items to the left */
            padding: 20px;
        }

        /* Title Styling */
        .content h1 {
            margin-bottom: 20px;
            /* Space between title and form */
            font-size: 24px;
            color: #333;
        }

        /* Form Wrapper Styling */
        .form-container {
            background-color: #87CEEB;
            width: 100%;
            max-width: 600px;
            padding: 40px 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: left;
        }

        /* Label Styling */
        .form-container label {
            display: inline-block;
            width: 150px;
            text-align: left;
            padding: 10px 0;
            font-weight: bold;
            color: #333;
        }

        /* Input Fields */
        .form-container input[type="text"],
        .form-container textarea,
        .form-container input[type="file"] {
            width: calc(100% - 170px);
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-left: 10px;
            box-sizing: border-box;
        }

        /* Image Styling */
        .form-container img {
            margin-left: 160px;
            margin-top: 10px;
            border: 2px solid #ddd;
            border-radius: 4px;
        }

        /* Submit Button */
        .form-container .btn {
            margin-top: 20px;
            padding: 10px 20px;
            color: #fff;
            background-color: #28a745;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .form-container .btn:hover {
            background-color: #218838;
        }
    </style>
</head>

<body>
    <?php include 'admin_sidebar.php'; ?>

    <div class="content">
        <!-- Title Section -->
        <h1>Update Teacher Data</h1>

        <!-- Form Section -->
        <form class="form-container" action="admin_update_teacher.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?php echo $info['id']; ?>">

            <div>
                <label>Teacher Name</label>
                <input type="text" name="name" value="<?php echo $info['name']; ?>" required>
            </div>

            <div>
                <label>About Teacher</label>
                <textarea name="description" rows="4" required><?php echo $info['description']; ?></textarea>
            </div>

            <div>
                <label>Teacher Old Image</label>
                <img width="100px" height="100px" src="<?php echo $info['image']; ?>" alt="Current Image">
            </div>

            <div>
                <label>Choose Teacher New Image</label>
                <input type="file" name="image" accept="image/*">
            </div>

            <div>
                <input class="btn" type="submit" name="update_teacher" value="Update">
            </div>
        </form>
    </div>

</body>

</html>