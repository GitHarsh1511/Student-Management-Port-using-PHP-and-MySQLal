<?php

session_start();

if (!isset($_SESSION['username'])) {
    header("location:login.php");
} elseif ($_SESSION['usertype'] == 'student') {
    header("location:login.php");
}

$host = "localhost";
$user = "root";
$password = "";
$db = "mnpwd";

$data = mysqli_connect($host, $user, $password, $db);

if (isset($_POST['add_teacher'])) {
    $t_name = $_POST['name'];
    $t_description = $_POST['description'];
    $file = $_FILES['image']['name'];

    $dst = "./image/" . $file;

    $dst_db = "image/" . $file;

    move_uploaded_file($_FILES['image']['tmp_name'], $dst);

    $sql = "INSERT INTO teacher (name,description,image) VALUES ('$t_name','$t_description','$dst_db')";

    $result = mysqli_query($data, $sql);

    if ($result) {
        header('location:admin_add_teacher.php');
    }
}
?>







<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <?php

    include 'admin_css.php';

    ?>

    <style type="text/css">
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }

        .content {
            padding: 10px;
            text-align: center;
        }

        .div_deg {
            background-color: #87CEFA;
            /* skyblue */
            padding: 20px;
            width: 100%;
            max-width: 400px;
            margin: 0 auto;
            border-radius: 8px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        /* h1 {
            font-size: 20px;
            margin-bottom: 15px;
            color: #333;
        } */

        form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        label {
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 5px;
            color: #333;
        }

        input[type="text"],
        textarea,
        input[type="file"] {
            padding: 8px;
            font-size: 14px;
            border-radius: 4px;
            border: 1px solid #ccc;
            width: 100%;
            box-sizing: border-box;
            transition: border-color 0.3s;
        }

        input[type="text"]:focus,
        textarea:focus,
        input[type="file"]:focus {
            border-color: #007bff;
            outline: none;
        }

        textarea {
            resize: vertical;
            min-height: 80px;
        }

        .btn {
            padding: 8px 15px;
            background-color: #007bff;
            color: white;
            font-size: 14px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .btn-primary {
            width: auto;
            max-width: 180px;
            margin-top: 15px;
        }
    </style>


</head>

<body>
    <?php

    include 'admin_sidebar.php';

    ?>

    <div class="content">
        <center>

            <h1>Add Teacher</h1>
            <div class="div_deg">

                <form action="#" method="POST" enctype="multipart/form-data">
                    <div>
                        <label>Teacher Name :</label>
                        <input type="text" name="name">
                    </div>

                    <br>

                    <div>
                        <label>Description :</label>
                        <textarea name="description"></textarea>
                    </div>

                    <br>

                    <div>
                        <label>Image :</label>
                        <input type="file" name="image">
                    </div>

                    <br>

                    <div>

                        <input type="submit" name="add_teacher" value="Add Teacher" class="btn btn-primary">
                    </div>
                </form>
            </div>


        </center>
    </div>
</body>

</html>