<?php

session_start();

if (!isset($_SESSION['username'])) {
    header("location:login.php");
} elseif ($_SESSION['usertype'] == 'student') {
    header("location:login.php");
}

$host = "localhost";
$user = "root";
$password = "";
$db = "mnpwd";

$data = mysqli_connect($host, $user, $password, $db);

$id = $_GET['student_id'];

$sql = "SELECT * FROM user WHERE id='$id' ";

$result = mysqli_query($data, $sql);

$info = $result->fetch_assoc();

if (isset($_POST['update'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];

    // Check if a new image is uploaded
    $file = $_FILES['image']['name'];
    $dst = "./images/" . $file;  // Path to save the uploaded image
    $dst_db = "images/" . $file;  // Path to save in the database

    // Move uploaded image to the server
    if ($file) {
        move_uploaded_file($_FILES['image']['tmp_name'], $dst);

        // Update the image along with other details
        $query = "UPDATE user SET username='$name', email='$email', phone='$phone', password='$password', image='$dst_db' WHERE id='$id' ";
    } else {
        // If no image is uploaded, just update other details
        $query = "UPDATE user SET username='$name', email='$email', phone='$phone', password='$password' WHERE id='$id' ";
    }

    $result2 = mysqli_query($data, $query);

    if ($result2) {
        header("location:view_student.php");
    }
}

?>







<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <?php

    include 'admin_css.php';

    ?>

    <style type="text/css">
        /* Label styling */
        label {
            display: inline-block;
            text-align: left;
            width: 120px;
            padding-top: 8px;
            padding-bottom: 8px;
            font-size: 16px;
            font-weight: bold;
            color: #333;
        }

        /* Container div styling */
        .div_deg {
            background-color: #87CEFA;
            width: 50%;
            /* Adjust width for responsiveness */
            margin: 0 auto;
            padding: 40px 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.15);
            text-align: left;
            overflow: hidden;
        }

        /* Form field styling */
        input[type="text"],
        input[type="email"],
        input[type="number"],
        input[type="file"] {
            width: calc(100% - 140px);
            /* Adjust for label width and padding */
            padding: 10px;
            margin-top: 8px;
            font-size: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            /* Ensure padding and borders are included in the width */
        }

        /* Center-align the old image, new image, and submit button */
        .center-content {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }

        /* Image styling for preview */
        img {
            width: 100px;
            height: 100px;
            border-radius: 8px;
            margin-top: 10px;
        }

        /* Button styling */
        .btn-primary {
            background-color: #007bff;
            color: white;
            padding: 12px 20px;
            margin-top: 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        /* Button container to center-align */
        .button-container {
            text-align: center;
            margin-top: 20px;
        }

        /* Adjust input widths for better appearance */
        input[type="file"] {
            width: 100%;
        }

        /* Center the form container */
        .center {
            text-align: center;
        }
    </style>
</head>

<body>
    <?php

    include 'admin_sidebar.php';

    ?>

    <div class="content">
        <center>
            <h1>Update Student</h1>
            <br><br>
            <div class="div_deg">

                <form action="#" method="POST">

                    <div>
                        <label>Username</label>
                        <input type="text" name="name" value="<?php echo $info['username']; ?>">
                    </div>
                    <div>
                        <label>Email</label>
                        <input type="email" name="email" value="<?php echo $info['email']; ?>">
                    </div>
                    <div>
                        <label>Phone</label>
                        <input type="number" name="phone" value="<?php echo $info['phone']; ?>">
                    </div>
                    <div>
                        <label>Password</label>
                        <input type="text" name="password" value="<?php echo $info['password']; ?>">
                    </div>
                    <div>

                    </div>
                    <div class="button-container">
                        <input class="btn btn-success" type="submit" name="update" value="Update">
                    </div>
                </form>
            </div>
        </center>
    </div>
</body>

</html>