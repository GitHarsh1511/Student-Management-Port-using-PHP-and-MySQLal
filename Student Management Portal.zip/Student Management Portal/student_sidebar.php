<header class="header">
    <a href="studenthome.php">Student Dashboard</a>

    <div class="logout">
        <a href="logout.php" class="btn btn-primary">Logout</a>
    </div>
</header>

<aside>

    <ul>

        <li>
            <a href="student_profile.php">Update Profile</a>
        </li>
    </ul>
</aside>