<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("location:login.php");
} elseif ($_SESSION['usertype'] == 'student') {
    header("location:login.php");
}

$host = "localhost";
$user = "root";
$password = "";
$db = "mnpwd";

$data = mysqli_connect($host, $user, $password, $db);

if (isset($_POST['add_student'])) {
    $username = $_POST['name'];
    $user_email = $_POST['email'];
    $user_phone = $_POST['phone'];
    $user_password = $_POST['password'];
    $usertype = "student";

    // Check if image is uploaded
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['image']['name'];
        $dst = "./image/" . $file;
        $dst_db = "image/" . $file;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $dst)) {
            $sql = "INSERT INTO user (username, email, phone, usertype, password, image) VALUES ('$username', '$user_email', '$user_phone', '$usertype', '$user_password', '$dst_db')";
            $result = mysqli_query($data, $sql);

            if ($result) {
                echo "<script type='text/javascript'>
                        alert('Student Added Successfully.');
                        window.location.href = 'add_student.php'; // Ensure the correct path
                      </script>";
                exit(); // Prevents further code execution after redirect
            } else {
                echo "<script type='text/javascript'> alert('Failed to Add Student.'); </script>";
            }
        } else {
            echo "<script type='text/javascript'> alert('Failed to upload image.'); </script>";
        }
    } else {
        echo "<script type='text/javascript'> alert('Please select an image to upload.'); </script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>

    <style type="text/css">
        /* Label styling */
        label {
            display: inline-block;
            text-align: left;
            width: 120px;
            padding-top: 8px;
            padding-bottom: 8px;
            font-size: 16px;
            font-weight: bold;
            color: #333;
        }

        /* Container div styling */
        .div_deg {
            background-color: #87CEFA;
            width: 400px;
            margin: 0 auto;
            padding: 40px 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.15);
            text-align: left;
        }

        /* Form field styling */
        input[type="text"],
        input[type="email"],
        input[type="number"],
        input[type="file"] {
            width: calc(100% - 130px);
            padding: 8px;
            margin-top: 8px;
            font-size: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        /* Button styling */
        .btn-primary {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            margin-top: 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        /* Button container to center-align */
        .button-container {
            text-align: center;
            margin-top: 20px;
        }
    </style>

    <?php
    include 'admin_css.php';
    ?>

</head>

<body>
    <?php
    include 'admin_sidebar.php';
    ?>

    <div class="content">
        <center>
            <h1>Add Student</h1>
            <br>
            <div class="div_deg">
                <form action="#" method="POST" enctype="multipart/form-data">
                    <div>
                        <label>Username</label>
                        <input type="text" name="name" required>
                    </div>

                    <div>
                        <label>Email</label>
                        <input type="email" name="email" required>
                    </div>

                    <div>
                        <label>Phone</label>
                        <input type="number" name="phone" required>
                    </div>

                    <div>
                        <label>Password</label>
                        <input type="text" name="password" required>
                    </div>

                    <div>
                        <label>Image :</label>
                        <input type="file" name="image" required>
                    </div>

                    <div class="button-container">
                        <input class="btn btn-primary" type="submit" name="add_student" value="Add Student">
                    </div>
                </form>
            </div>
        </center>
    </div>
</body>

</html>